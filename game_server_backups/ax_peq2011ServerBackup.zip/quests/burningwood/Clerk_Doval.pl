sub EVENT_DEATH
{
   quest::say("All Iksar residents.. shall learn.. of my demise. Ungghh!!");
   quest::signalwith(87101,1);
}