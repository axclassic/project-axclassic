# Khati Sha Event
# Succed grimling
# Signal upon death to Arcanist V2. Start next part of event.
# Created by Gonner


sub EVENT_DEATH {
	quest::signalwith(154151,9,10); #sends signal to arcanist V1
}

#END of FILE zone:acrylia ID:154129 -- a_diseased_grimling.pl
