# Khati Sha Event
# Fail grimling
# Signal upon death to Arcanist V1. When 4 die event is over.
# Created by Gonner


sub EVENT_DEATH {
	quest::signalwith(154152,8,10); #sends signal to arcanist V1
	}
	

#END of FILE zone:acrylia ID:154159 -- a_diseased_grimling.pl
