# Khati Sha Event
# Created by Gonner


sub EVENT_SIGNAL {
	quest::depop();
}
    
#END of FILE zone:acrylia ID:154045 -- Defiled_Minion.pl   
    
 