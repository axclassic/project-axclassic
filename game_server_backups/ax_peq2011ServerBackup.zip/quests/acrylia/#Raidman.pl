# Khati Sha Event
# Ward of Spirit V2
# Created by Gonner


sub EVENT_SPAWN {
	quest::spawn2(154152,0,0,631.00, -395.00, -23.00,187); # Spiritual Arcanist V2
	quest::spawn2(154151,0,0,631.00, -357.00, -23.00,187); # Spiritual Arcanist V1
	
	
	quest::spawn2(154129,0,0,614.00, -406.00, -23.00,187); # grimling V1
	quest::spawn2(154129,0,0,614.00, -381.00, -23.00,187); # grimling V1
	quest::spawn2(154129,0,0,645.00, -406.00, -23.00,187); # grimling V1
	quest::spawn2(154129,0,0,645.00, -381.00, -23.00,187); # grimling V1
	
	
	quest::spawn2(154129,0,0,614.00, -345.00, -23.00,187); # grimling V2
	quest::spawn2(154129,0,0,614.00, -368.00, -23.00,187); # grimling V2
	quest::spawn2(154129,0,0,645.00, -345.00, -23.00,187); # grimling V2
	quest::spawn2(154129,0,0,645.00, -368.00, -23.00,187); # grimling V2

	quest::depop();
}
	
#END of FILE zone:acrylia ID:154122 -- #raidman.pl
	
