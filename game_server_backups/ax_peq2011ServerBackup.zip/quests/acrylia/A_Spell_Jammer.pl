# Khati Sha Event
# Created by Gonner

sub EVENT_DEATH {
	quest::signalwith(154130,1,10);
}

#END of FILE zone:acrylia ID:154147 -- A_Spell_Jammer.pl

