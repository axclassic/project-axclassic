# Khata Sha The Twisted
# Created by Gonner


sub EVENT_DEATH {
	quest::signalwith(154130,5,10);
}

#END of FILE zone:acrylia ID:154053 -- Spiritist_Andro_Shimi.pl

