# Khati Sha Event
# Created by Gonner


sub EVENT_DEATH {
	quest::signalwith(154130,5,10);
	}
	
#END of FILE zone:acrylia ID:154156 -- Spiritist_Kama_Resan.pl  V2

