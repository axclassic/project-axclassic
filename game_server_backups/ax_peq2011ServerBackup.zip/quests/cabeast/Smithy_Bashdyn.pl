sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Shields up. my friend!!  My talents of rebirth are here to aid thee.  Only the finest shields shall you find among my works of art."); }
}
#END of FILE Zone:cabeast  ID:4666 -- Smithy_Bashdyn 

