# Test of Illusion - enchanter epic - Xolion Rod
# 

sub EVENT_DEATH {
  quest::say("You may get the Rod of Xolion, but the Crusaders of Greenmist will encase you in this pit!");
}

# EOF Zone: cabeast ID: 106008 NPC: Vessel_Drozlin

