sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Do not complain to me of the prices.  I charge what the Haggle Baron instructs me to charge."); }
}
#END of FILE Zone:cabeast  ID:3055 -- Klok_Wyga 

