sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail. citizen!  Keep clear of the waterways which run through this grand city.  For swimming they are not.  Many times have playful broodlings fallen prey to the sharp teeth of barracudas."); }
}
#END of FILE Zone:cabeast  ID:5131 -- Trooper_Nishnish 

