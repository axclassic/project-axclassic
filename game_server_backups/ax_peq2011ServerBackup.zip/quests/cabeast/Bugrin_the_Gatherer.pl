sub EVENT_SPAWN {
  quest::say("You will never take me alive!!");
}

sub EVENT_DEATH {
  quest::say("hisss.. You will never stop the.. Radiant.. Green..");
}