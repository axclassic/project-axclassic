sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("I. Brewer Prixal. am the maker of the heartiest drinks in all of Kunark! Have a look at my astonishing assortment of beverages!"); }
}
#END of FILE Zone:cabeast  ID:396 -- Brewer_Prixal 

