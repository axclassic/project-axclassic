sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("I have much work to do for the Legion of Cabilis! Have you come to view my wares. or to learn the art of weapon smithing so that you may assist me in crafting weapons for our warriors?"); }
}
#END of FILE Zone:cabeast  ID:5762 -- Smithy_Krikt 

