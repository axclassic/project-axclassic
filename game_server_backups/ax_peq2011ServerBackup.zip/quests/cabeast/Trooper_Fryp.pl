sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail. citizen!  Have you been fishing lately?  The water is alive with sewer catfish. Unfortunately. there are also the barracudas!!"); }
}
#END of FILE Zone:cabeast  ID:5104 -- Trooper_Fryp 

