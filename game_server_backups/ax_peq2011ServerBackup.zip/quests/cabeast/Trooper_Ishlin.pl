sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("I wish to earn heavy coin so I can meet with the Kloks in the Haggle Baron's house.  They are said to have the finest merchandise available in Cabilis."); }
}
#END of FILE Zone:cabeast  ID:5117 -- Trooper_Ishlin 

