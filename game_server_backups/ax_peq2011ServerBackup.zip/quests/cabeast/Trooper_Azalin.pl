sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Look to the center of Cabilis and you shall find the Kloks.  They will have all the provisions you will need for any adventuring you may do."); }
}
#END of FILE Zone:cabeast  ID:5092 -- Trooper_Azalin 

