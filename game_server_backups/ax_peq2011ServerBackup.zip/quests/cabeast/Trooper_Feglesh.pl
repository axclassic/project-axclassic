sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("If sweets are your fancy. seek out the chefs of Cabilis.  They have much to offer."); }
}
#END of FILE Zone:cabeast  ID:5102 -- Trooper_Feglesh 

