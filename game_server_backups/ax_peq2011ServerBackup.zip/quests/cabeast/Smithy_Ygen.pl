sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Good day!  If you wish to survive the wilds of Kunark. you had best purchase some of my wares.  Here you may find he finest metals forged by the finest smiths."); }
}
#END of FILE Zone:cabeast  ID:4670 -- Smithy_Ygen 

