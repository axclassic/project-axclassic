sub EVENT_AGGRO { 
  quest::say("Yikitu uxen jidak!");
}

#END of FILE Zone:akheva  ID:179005 -- Transient_Patroller 

