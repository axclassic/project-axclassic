sub EVENT_DEATH {
quest::signalwith(71056,1,1);
}