sub EVENT_DEATH {
   quest::spawn2(71034,0,0,-540.6,767.1,174.1,65);
   }