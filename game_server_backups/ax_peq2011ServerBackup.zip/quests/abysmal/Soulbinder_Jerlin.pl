#generic soulbinder quest
sub EVENT_SAY { 
	plugin::soulbinder_say($text);
}