sub EVENT_SPAWN {
  plugin::RandomRoam(500,500,5,15);
}