sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Pleasure to meet you.  Keep your eye out for the ship.  You don't want to miss it."); }
}
#END of FILE Zone:butcher  ID:68064 -- Glorin_Binfurr 

