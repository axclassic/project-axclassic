sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Looking for a challenging fray?  Perhaps there is a combatant waiting for a duel within the Gauntlet."); }
}
#END of FILE Zone:cabwest  ID:2103 -- Gryzil 

