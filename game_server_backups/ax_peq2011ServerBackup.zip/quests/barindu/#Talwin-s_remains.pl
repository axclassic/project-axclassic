sub EVENT_SPAWN {
  plugin::SetAnim(dead);
}