sub EVENT_DEATH {
  quest::depop(283153);
  quest::spawn2(283048,0,0,-574,568,-98,168);
}