sub EVENT_DEATH { 
#quest::summonitem("13169");	
}
#END of FILE Zone:befallen  ID:4953 -- the_thaumaturgist 

