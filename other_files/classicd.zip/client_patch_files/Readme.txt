Make sure to set the config file to your servers needs.
Once these are set you can send it to them, Make sure you
send them 2 files the .exe and the .config. I kept this 
very small with emailing in mind.

If you have any questions Just email me leslamarch@gmail.com

**NOTE** this requires .net framework 2.0

Best regards,
Les LaMarch

EDIT;
Unzip this into your Everquest client directory, the settings.ini file
is currently pointed to AX Classic test server- if you don't change
the settings, that's where you'll be playing. Which is fine by me,
if you don't have an account, you have to make one at the forums.
I play there too , so accounts are preserved.
Angelox